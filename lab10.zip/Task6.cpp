#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node* next;
    Node* prev;

    Node(int d)
    {
        data = d;
        next = NULL;
        prev = NULL;
    }
};

class DoublyLinkedList
{
private:
    Node* head;

public:
    DoublyLinkedList()
    {
        head = NULL;
    }

    // Insert at End
    Node* insertEnd(Node* temp, int value)
    {
        if (temp == NULL)
            return new Node(value);

        if (temp->next == NULL)
        {
            Node* newNode = new Node(value);
            temp->next = newNode;
            newNode->prev = temp;
            return temp;
        }

        temp->next = insertEnd(temp->next, value);

        return temp;
    }

    void insert(int value)
    {
        head = insertEnd(head, value);
    }

    void printForward(Node* temp)
    {
        if (temp == NULL)
            return;

        cout << temp->data << " ";
        printForward(temp->next);
    }

    void printReverse(Node* temp)
    {
        if (temp == NULL)
            return;

        cout << temp->data << " ";
        printReverse(temp->prev);
    }

    Node* getLast(Node* temp)
    {
        if (temp == NULL || temp->next == NULL)
            return temp;

        return getLast(temp->next);
    }

    bool palindrome(Node* left, Node* right)
    {
        if (left == NULL || right == NULL)
            return true;

        if (left == right || right->next == left)
            return true;

        if (left->data != right->data)
            return false;

        return palindrome(left->next, right->prev);
    }

    bool isPalindrome()
    {
        return palindrome(head, getLast(head));
    }

    void displayForward()
    {
        printForward(head);
        cout << endl;
    }

    void displayReverse()
    {
        Node* last = getLast(head);
        printReverse(last);
        cout << endl;
    }
};

int main()
{
    DoublyLinkedList list;

    list.insert(1);
    list.insert(2);
    list.insert(3);
    list.insert(2);
    list.insert(1);

    cout << "Forward: ";
    list.displayForward();

    cout << "Reverse: ";
    list.displayReverse();

    if (list.isPalindrome())
        cout << "Palindrome";
    else
        cout << "Not Palindrome";

    return 0;
}