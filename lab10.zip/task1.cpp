#include<iostream>
using namespace std;

int arraysum(int arr[], int n) {
	if (n <= 0) {
		return 0;

	}

	else {
		return arr[n - 1] + arraysum(arr, n - 1);
	}
}


int main() {

	int arr1[5] = { 23,45,12,34 };

	cout << "Sum is " << arraysum(arr1, 4)<<endl;



	return 0;
}