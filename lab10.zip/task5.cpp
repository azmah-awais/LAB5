#include <iostream>
using namespace std;

class  Node
{
public:
    int data;
    Node* next;

    Node(int d)
    {
        data = d;
        next = NULL;
    }
};

class LinkedList
{
private:
    Node* head;

public:
    LinkedList()
    {
        head = NULL;
    }

    void print(Node* temp)
    {
        if (temp == NULL)
            return;

        cout << temp->data << " ";
        print(temp->next);
    }

    void display()
    {
        print(head);
        cout << endl;
    }


    void insertAtBeginning(int value)
    {
        Node* newNode = new Node(value);
        newNode->next = head;
        head = newNode;
    }


    Node* insertAtEnd(Node* temp, int value)
    {
        if (temp == NULL)
            return new Node(value);

        temp->next = insertAtEnd(temp->next, value);

        return temp;
    }

    void insertEnd(int value)
    {
        head = insertAtEnd(head, value);
    }

    Node* insertAtPosition(Node* temp, int value, int pos)
    {
        if (pos == 1)
        {
            Node* newNode = new Node(value);
            newNode->next = temp;
            return newNode;
        }

        if (temp == NULL)
            return NULL;

        temp->next = insertAtPosition(temp->next, value, pos - 1);

        return temp;
    }

    void insertPosition(int value, int pos)
    {
        head = insertAtPosition(head, value, pos);
    }

    Node* deleteByValue(Node* temp, int value)
    {
        if (temp == NULL)
            return NULL;

        if (temp->data == value)
        {
            Node* del = temp;
            temp = temp->next;
            delete del;
            return temp;
        }

        temp->next = deleteByValue(temp->next, value);

        return temp;
    }

    void deleteValue(int value)
    {
        head = deleteByValue(head, value);
    }


    Node* deleteAtPosition(Node* temp, int pos)
    {
        if (temp == NULL)
            return NULL;

        if (pos == 1)
        {
            Node* del = temp;
            temp = temp->next;
            delete del;
            return temp;
        }

        temp->next = deleteAtPosition(temp->next, pos - 1);

        return temp;
    }

    void deletePosition(int pos)
    {
        head = deleteAtPosition(head, pos);
    }


    int search(Node* temp, int value, int pos)
    {
        if (temp == NULL)
            return -1;

        if (temp->data == value)
            return pos;

        return search(temp->next, value, pos + 1);
    }

    int searchValue(int value)
    {
        return search(head, value, 1);
    }
};

int main()
{
    LinkedList list;

    list.insertAtBeginning(10);
    list.insertEnd(20);
    list.insertEnd(30);
    list.insertPosition(15, 2);

    cout << "List: ";
    list.display();

    list.deleteValue(20);

    cout << "After deleting 20: ";
    list.display();

    cout << "Position of 30: "
        << list.searchValue(30);

    return 0;
}